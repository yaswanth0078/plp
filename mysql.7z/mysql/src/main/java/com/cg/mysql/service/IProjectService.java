package com.cg.mysql.service;

import java.util.List;

import javax.validation.Valid;

import com.cg.mysql.entity.Project;

public interface IProjectService {

	Project insertData(@Valid Project project);

	List<Project> getAllDetails();

	Project getDetailsById(int id);

	Project updateDetailsById(int id, Project project);

	Project deleteDetailsById(int id);

}
